package com.example.springbootPostgres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootPostgresApplicationTests {

	@Test
	void contextLoads() {
	}

}
